#define assert(x)
